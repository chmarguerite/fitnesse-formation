package org.fitnesse.tp.fixtures;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

public class SetupDriver {
	public static WebDriver driver;
	
	public  SetupDriver() {}
	
	public void init() {
		System.setProperty("webdriver.gecko.driver", "drivers/geckodriver.exe");
		driver = new FirefoxDriver();	
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	public void ouvrirLApplication(String url) {
		url = url.replaceAll("\\<.*?\\>", "");
		driver.get(url);
	}
	
    public void fermerLeNavigateur(){
        driver.quit();
    }

	
}
