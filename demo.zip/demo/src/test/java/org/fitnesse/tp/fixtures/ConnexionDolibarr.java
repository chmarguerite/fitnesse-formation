package org.fitnesse.tp.fixtures;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ConnexionDolibarr extends SetupDriver {
	@FindBy(id="username")
	WebElement txtLogin;
	@FindBy(id="password")
	WebElement txtPassword;
	@FindBy(className="button")
	WebElement btnLogin;
	
	public void jeLanceLApplicationDolibarr() {
		this.init();
		driver.get("http://dolibarr.selenium-formation.org");
		PageFactory.initElements(driver, this);
	}

	public void jeMeConnecteAvecLIdentifiantEtSonMotDePasse(String username, String password) throws InterruptedException {
		txtLogin.sendKeys(username);
		txtPassword.sendKeys(password);
		btnLogin.click();
		Thread.sleep(5000);
	}
	
	public void jeFermeLApplicationDolibarr() {
		driver.quit();
	}
}
