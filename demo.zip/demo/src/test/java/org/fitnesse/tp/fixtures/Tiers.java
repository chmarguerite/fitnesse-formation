package org.fitnesse.tp.fixtures;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Tiers extends SetupDriver {
	
	@FindBy(id="name")
	WebElement txtNomDuTiers;
	@FindBy(id="customer_code")
	WebElement txtCodeClient;
	@FindBy(name="client")
	WebElement lstProspectClient;
	@FindBy(name="fournisseur")
	WebElement lstFournisseur;
	@FindBy(name="create")
	WebElement btnCr�erTiers;
	@FindBy(id="email")
	WebElement txtEmail;
	@FindBy(name="search_customer_code")
	WebElement txtRechercheCodeCLient;
	
	public Tiers() {
		PageFactory.initElements(driver, this);
	}
	public void jeNavigueAuFormulaireDeNouveauTiers() {
		driver.findElement(By.linkText("Tiers")).click();
		driver.findElement(By.linkText("Nouveau tiers")).click();
	}
	
	public void jeCr�eUnNouveauTiersAvecLesInformations(Map<String, String> infosClient) {
		if(infosClient.containsKey("Nom")) {txtNomDuTiers.sendKeys(infosClient.get("Nom"));}
		if(infosClient.containsKey("Prospect / Client")) {
			new Select(lstProspectClient).selectByVisibleText(infosClient.get("Prospect / Client"));
			}
		if(infosClient.containsKey("Fournisseur")) {
			new Select(lstFournisseur).selectByVisibleText(infosClient.get("Fournisseur"));
			}
		if(infosClient.containsKey("Email")) {
			txtEmail.sendKeys(infosClient.get("Email").replaceAll("\\<.*?\\>", ""));}
	}
	
	public String  jeR�cup�reLeCodeClient() {
		return txtCodeClient.getAttribute("value");
		
	}
	
	public void jeRechercheLeTiersAvecLeCodeClient(String codeClient) throws InterruptedException {
		driver.findElement(By.linkText("Liste des clients")).click();
		txtRechercheCodeCLient.sendKeys(codeClient);
		new Actions(driver).sendKeys(Keys.ENTER).perform();
		driver.findElement(By.xpath("//a[contains(@title,'" + codeClient + "')]")).click();
		Thread.sleep(3000);
	}
	public void  jeValideLeNouveauTiers() throws InterruptedException {
		Thread.sleep(3000);
		btnCr�erTiers.click();
		Thread.sleep(3000);
		
	}
	
}
