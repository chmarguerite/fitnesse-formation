package org.fitnesse.demo.fixtures;

public class MathFixture {
	private int firstNumber;
	private int secondNumber;
	
	public void setFirstNumber(int firstNumber) {
		this.firstNumber = firstNumber;
	}
	public void setSecondNumber(int secondNumber) {
		this.secondNumber = secondNumber;
	}
	
	public int theGreaterIs() {
		return Math.max(firstNumber, secondNumber);
	}

}
