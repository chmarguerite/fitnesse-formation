package org.fitnesse.demo.fixtures;

import fit.ColumnFixture;

public class MathFitFixture extends ColumnFixture {

	private int firstNumber;
	private int secondNumber;
	
	public int theGreaterIs() {
		return Math.max(firstNumber, secondNumber);
	}
}
