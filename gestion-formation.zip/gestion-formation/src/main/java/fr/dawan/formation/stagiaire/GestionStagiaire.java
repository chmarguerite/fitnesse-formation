package fr.dawan.formation.stagiaire;


import java.util.*;

public class GestionStagiaire implements GestionStagiaireInterface {
    
    public GestionStagiaire() {}



    public Stagiaire consulterStagiaire(String nom) {
        return new Stagiaire(nom);
    }

    public Double calculerNoteMoyenne(Stagiaire stagiaire) {
		return null;
    }

	public String consulterResultatExamen(Stagiaire stagiaire) {
		if(stagiaire.getNoteMoyenne()<9) {return "Refus�";}
		if(9<= stagiaire.getNoteMoyenne() && stagiaire.getNoteMoyenne() < 10 ) {return "Rattrapage";}
		if(stagiaire.getNoteMoyenne() >= 10) {return "Admis";}
		return null;
	}



	public void ajouterNote(Stagiaire stagiaire, String cours, Integer note) {
		Note objNote = new Note();
		objNote.setNom(stagiaire.getNom());
		objNote.setCours(cours);
		objNote.setNote(note);
		stagiaire.getNotes().add(objNote);
	}



	public Double calculerNoteMoyenneModule(Stagiaire stagiaire, String cours) {
		return stagiaire.getNotes().stream()
		.filter(note -> cours.equals(note.getCours()))
		.mapToDouble(note -> note.getNote())
        .average()
        .getAsDouble();
	}

}





/****
 return notes.stream().mapToDouble(Note::getNote)
 .average().getAsDouble();****/