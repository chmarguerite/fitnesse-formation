package fr.dawan.formation.stagiaire;


import java.util.List;

public interface GestionStagiaireInterface {

	public List<Stagiaire> obtenirListeStagiaires();
    public Stagiaire consulterStagiaire(String matricule);
    public void ajouterNote(Stagiaire stagiaire, String cours,Integer note);
    public Double calculerNoteMoyenne(Stagiaire stagiaire);
    public Double calculerNoteMoyenneModule(Stagiaire stagiaire, String cours);
    public String consulterResultatExamen(Stagiaire stagiaire);


}
