package fr.dawan.formation.stagiaire;


public class Note {


    private String nom;
    private String cours;
    private Integer note;

    public Note(){}

    public Note(String nom, String cours, Integer note){
        this.setNom(nom);
        this.setCours(cours);
        this.setNote(note);
    }

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getCours() {
		return cours;
	}

	public void setCours(String cours) {
		this.cours = cours;
	}

	public Integer getNote() {
		return note;
	}

	public void setNote(Integer note) {
		this.note = note;
	}

}
