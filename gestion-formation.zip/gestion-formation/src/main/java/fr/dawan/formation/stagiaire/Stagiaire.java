package fr.dawan.formation.stagiaire;


import java.util.ArrayList;
import java.util.List;
import fr.dawan.formation.stagiaire.Note;

public class Stagiaire {

    private String nom;
    private List<Note> notes = new ArrayList<Note>();
    private double noteMoyenne;

    public Stagiaire(){}

    public Stagiaire(String nom){
        this.setNom(nom);
    }

    public Stagiaire(String nom, Double noteMoyenne){
        this.setNom(nom);
        this.setNoteMoyenne(noteMoyenne);
    }

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public List<Note> getNotes() {
		return notes;
	}

	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}

	public double getNoteMoyenne() {
		return noteMoyenne;
	}

	public void setNoteMoyenne(double noteMoyenne) {
		this.noteMoyenne = noteMoyenne;
	}


}
